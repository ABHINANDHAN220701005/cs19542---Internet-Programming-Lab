# Real-Estate-Management-System-Project-In-PHP-Free-Download-Source-Code
Real-Estate-Management-System-Project-In-PHP-Free-Download-Source-Code



Developed by Abdul Rahman Al-Harbi

![image](https://github.com/Abutamim3/Real-Estate-Management-System-Project-In-PHP-Free-Download-Source-Code/blob/main/Real-Estate-Management-System-Project-In-PHP-Free-Download-Source-Code/resw/1444-10-27_15h46_44.png)
![image](https://github.com/Abutamim3/Real-Estate-Management-System-Project-In-PHP-Free-Download-Source-Code/blob/main/Real-Estate-Management-System-Project-In-PHP-Free-Download-Source-Code/resw/1444-10-28_00h40_51.png)




**Developed By  Abdul Rahman Al-Harbi**



#THANK YOU FOR DOWNLOADING

*******************************************************

Step 1: Download source code.

First, download the source code given below.
download source code
Step 2: Extract file.

Second, after you finished download the source code, extract the zip file.
real estate management system zip file
Step 3: Copy project folder.

Third, copy the project folder and paste it into the xampp/htdocs folder.
real estate management system project folder
Step 4: Open xampp.

Fourth, open xampp and start the apache and MySQL.
real estate management system open xampp
Step 5: Open browser.

Fifth, Open a browser and go to URL “http://localhost/phpmyadmin/”
real estate management system open phpmyadmin
Step 6: Create database.

Sixth, click on databases tab and
*****************************************************************
 Create database naming “realestate”.
real estate management system create database


Step 7: Import “realestate.sql”.
**********************************************************************
Seventh, Click on browse file and select “realestate.sql” file which is inside “database” folder and after import click “go“.
real estate management system import sql file
Step 8: Open browser and type folder name.

Eight, Open a browser and go to URL “http://localhost/resw/”.
